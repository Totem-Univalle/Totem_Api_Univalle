﻿namespace Totem_API.Models
{
    public partial class Auth
    {
        public string Email { get; set; } = null!;

        public string Pass { get; set; } = null!;
    }
}
